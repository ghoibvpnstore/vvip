from xdxl import *

@bot.on(events.CallbackQuery(data=b'tr_ip'))
async def registrasii(event):
	async def registrasii_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Chose Limit IP**",buttons=[
[Button.inline(" 1 IP/USER ","1"),
Button.inline(" 2 IP/USER ","2")],
[Button.inline(" 3 IP/USER ","3"),
Button.inline(" 4 IP/USER ","4")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'bash /etc/bot/xdxl/shell/shell_change_ip ganti-ip-trojan "{user}" "{exp}"'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**•───────────────────────•**
   **Succes Change Limit IP Trojan** 
**•───────────────────────•**
**Username:** `{user}`
**Limit IP:** `{exp}`
**•───────────────────────•**
**» 🤖@ghoibstore**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await registrasii_(event)
	else:
		await registrasii_(event)

@bot.on(events.CallbackQuery(data=b'vl_ip'))
async def registrasii(event):
	async def registrasii_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Chose Limit IP**",buttons=[
[Button.inline(" 1 IP/USER ","1"),
Button.inline(" 2 IP/USER ","2")],
[Button.inline(" 3 IP/USER ","3"),
Button.inline(" 4 IP/USER ","4")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'bash /etc/bot/xdxl/shell/shell_change_ip ganti-ip-vless "{user}" "{exp}"'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**•───────────────────────•**
   **Succes Change Limit IP Vless** 
**•───────────────────────•**
**Username:** `{user}`
**Limit IP:** `{exp}`
**•───────────────────────•**
**» 🤖@ghoibstore**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await registrasii_(event)
	else:
		await registrasii_(event)

@bot.on(events.CallbackQuery(data=b'vm_ip'))
async def registrasii(event):
	async def registrasii_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Chose Limit IP**",buttons=[
[Button.inline(" 1 IP/USER ","1"),
Button.inline(" 2 IP/USER ","2")],
[Button.inline(" 3 IP/USER ","3"),
Button.inline(" 4 IP/USER ","4")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'bash /etc/bot/xdxl/shell/shell_change_ip ganti-ip-vmess "{user}" "{exp}"'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**•───────────────────────•**
   **Succes Change Limit IP Vmess** 
**•───────────────────────•**
**Username:** `{user}`
**Limit IP:** `{exp}`
**•───────────────────────•**
**» 🤖@ghoibstore**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await registrasii_(event)
	else:
		await registrasii_(event)

@bot.on(events.CallbackQuery(data=b'ssh_ip'))
async def registrasii(event):
	async def registrasii_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Chose Limit IP**",buttons=[
[Button.inline(" 1 IP/USER ","1"),
Button.inline(" 2 IP/USER ","2")],
[Button.inline(" 3 IP/USER ","3"),
Button.inline(" 4 IP/USER ","4")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'bash /etc/bot/xdxl/shell/shell_change_ip ganti-ip-ssh "{user}" "{exp}"'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**•───────────────────────•**
   **Succes Change Limit IP SSH** 
**•───────────────────────•**
**Username:** `{user}`
**Limit IP:** `{exp}`
**•───────────────────────•**
**» 🤖@ghoibstore**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await registrasii_(event)
	else:
		await registrasii_(event)
