from xdxl import *

@bot.on(events.CallbackQuery(data=b'change-quota'))
async def change_quota(event):
	async def change_quota_(event):
		inline = [
[Button.inline(" CHANGE QUOTA VMESS ","trial-ssh")],
[Button.inline(" CHANGE QUOTA VLESS ","delete-ssh")],
[Button.inline(" CHANGE QUOTA TROJAN ","login-ssh")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
  **👨‍💻 MENU CHANGE USER QUOTA 👨‍💻**
━━━━━━━━━━━━━━━━━━━━━━━ 
🇮🇩 **» Service:** `SSH OVPN`
❤️ **» Hostname/IP:** `{DOMAIN}`
🇵🇸 **» ISP:** `{z["isp"]}`
⚡ **» Country:** `{z["country"]}`
👨‍💻 **» @ghoibstore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await change_quota_(event)
	else:
		await change_quota_(event)

@bot.on(events.CallbackQuery(data=b'change-ip'))
async def change_ip(event):
	async def change_ip_(event):
		inline = [
[Button.inline(" CHANGE IP SSH ","ssh_ip")],
[Button.inline(" CHANGE IP VMESS ","vm_ip")],
[Button.inline(" CHANGE IP VLESS ","vl_ip")],
[Button.inline(" CHANGE IP TROJAN ","tr_ip")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
   **👨‍💻 MENU CHANGE LIMIT IP 👨‍💻**
━━━━━━━━━━━━━━━━━━━━━━━ 
🇮🇩 **» Service:** `SSH OVPN`
❤️ **» Hostname/IP:** `{DOMAIN}`
🇵🇸 **» ISP:** `{z["isp"]}`
⚡ **» Country:** `{z["country"]}`
👨‍💻 **» @ghoibstore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await change_ip_(event)
	else:
		await change_ip_(event)

#@bot.on(events.NewMessage(pattern=r"(?:/change|/sayang)$"))
#@bot.on(events.NewMessage(pattern=r"(?:.anuku|/anuku)$"))
@bot.on(events.CallbackQuery(data=b'change-limit'))
async def change_limit(event):
	async def change_limit_(event):
		inline = [
[Button.inline(" CHANGE LIMIT IP ","change-ip")],
[Button.inline(" CHANGE LIMIT QUOTA ","change-quota")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
    **👨‍💻 MENU CHANGE LIMIT 👨‍💻**
━━━━━━━━━━━━━━━━━━━━━━━ 
🇮🇩 **» Service:** `SSH OVPN`
❤️ **» Hostname/IP:** `{DOMAIN}`
🇵🇸 **» ISP:** `{z["isp"]}`
⚡ **» Country:** `{z["country"]}`
👨‍💻 **» @ghoibstore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await change_limit_(event)
	else:
		await change_limit_(event)
